# TP1_GRUPO_21

• Integrante 1 – Tomas Bottelli (DetsuDev)

• Integrante 2 – Santiago Romero (Sromero1905)

• Integrante 3 – Renato Canavesi

• Integrante 4 – Sebastian Fuentes (GreyTen1)
